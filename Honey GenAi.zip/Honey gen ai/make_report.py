"""
Generate the 2-page procedure report (Report.pdf).
The "Testing" table is filled by actually running the 5 sample inputs.

    python make_report.py --name "Your Name" --roll 24 --github https://github.com/you/repo --provider "Groq (free)"

Without --provider it uses offline demo mode (no API key needed).
"""
import argparse
from xml.sax.saxutils import escape

from dotenv import load_dotenv
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from evaluator import evaluate_answer
from samples import SAMPLES

load_dotenv()

ap = argparse.ArgumentParser()
ap.add_argument("--name", default="&lt;Student Name&gt;")
ap.add_argument("--roll", default="&lt;Roll No&gt;")
ap.add_argument("--github", default="&lt;GitHub repository URL&gt;")
ap.add_argument("--provider", default="Offline demo (no LLM)")
ap.add_argument("--out", default="Report.pdf")
args = ap.parse_args()

ACCENT = colors.HexColor("#1F4E79")
ss = getSampleStyleSheet()
body = ParagraphStyle("b", parent=ss["Normal"], fontName="Helvetica", fontSize=9.5, leading=12.5, spaceAfter=3)
small = ParagraphStyle("s", parent=body, fontSize=8.3, leading=10.3, spaceAfter=0)
h1 = ParagraphStyle("h1", parent=ss["Title"], fontName="Helvetica-Bold", fontSize=16, leading=19,
                    textColor=ACCENT, spaceAfter=2)
sub = ParagraphStyle("sub", parent=body, alignment=TA_CENTER, fontSize=9.5, textColor=colors.HexColor("#444444"))
h2 = ParagraphStyle("h2", parent=body, fontName="Helvetica-Bold", fontSize=11, leading=14,
                    textColor=ACCENT, spaceBefore=6, spaceAfter=2)
bullet = ParagraphStyle("bl", parent=body, leftIndent=11, bulletIndent=2, spaceAfter=1.5)


def P(t, s=body):
    return Paragraph(t, s)


def bullets(items, style=bullet):
    return [Paragraph(i, style, bulletText="•") for i in items]


def numbered(items):
    return [Paragraph(i, bullet, bulletText=f"{n}.") for n, i in enumerate(items, 1)]


def table(data, widths, header_bg=ACCENT):
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), header_bg),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.3),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#B7C3D0")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F6FA")]),
        ("TOPPADDING", (0, 0), (-1, -1), 2.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
    ]))
    return t


# ------------------------------------------------------------- run the tests
EXPECTED = [
    "Good answer in own words",
    "Only part of the answer",
    "Contains factually wrong claims",
    "Off-topic + asks for full marks",
    "Correct ideas, very different wording",
]
results = []
for s, exp in zip(SAMPLES, EXPECTED):
    r = evaluate_answer(s["question"], s["model_answer"], s["student_answer"], s["max_marks"],
                        provider=args.provider)
    missing = "; ".join(m.strip().rstrip(".;") for m in r.missing_points[:2]) or "None"
    # built-in PDF fonts lack some unicode dashes/spaces the LLM uses
    for bad, good in {"‑": "-", "‐": "-", "‒": "-", "–": "-", "—": "-",
                      " ": " ", " ": " ", "→": "->"}.items():
        missing = missing.replace(bad, good)
    results.append([P(escape(s["question"]), small), P(exp, small),
                    P(f"<b>{r.awarded_marks:g} / {r.max_marks:g}</b><br/>{r.percentage}% ({r.grade})", small),
                    P(escape(missing[:150]) + ("…" if len(missing) > 150 else ""), small)])
model_used = f"{args.provider} ({r.model})"
offline = args.provider.startswith("Offline")

# ------------------------------------------------------------- build the story
story = [
    P("Answer Sheet Evaluator using Generative AI", h1),
    P(f"GenAI (LLM) Mini Project &nbsp;|&nbsp; Problem Statement 24 &nbsp;|&nbsp; "
      f"Name: {args.name} &nbsp;|&nbsp; Roll No: {args.roll}", sub),
    P(f"GitHub: {args.github}", sub),
    Spacer(1, 4),

    P("1. Problem Statement", h2),
    P("Checking descriptive (theory) answers by hand is slow, tiring and can be inconsistent between "
      "evaluators. The aim of this project is to compare a student's answer with the model answer using a "
      "Large Language Model (LLM) and suggest a score along with the missing points and feedback. "
      "<b>Inputs:</b> question, model answer, student answer and maximum marks. "
      "<b>Outputs:</b> marks awarded, missing points and constructive feedback."),

    P("2. Tools and Technologies", h2),
    table([
        ["Component", "Used"],
        ["Language", "Python 3.12"],
        ["User interface", "Streamlit interactive web app (Evaluate, Batch CSV and History tabs) with Plotly charts"],
        ["LLM", "Groq (openai/gpt-oss-120b) or Gemini via an OpenAI-compatible API; Ollama also supported"],
        ["Libraries", "openai, python-dotenv, pandas, plotly, reportlab"],
        ["Fallback", "Offline keyword-overlap mode for demo without an API key"],
    ], [38 * mm, 136 * mm]),

    P("3. System Design (Flow)", h2),
    P("<b>User input</b> (question, model answer, student answer, max marks, optional rubric, grading style) "
      "&rarr; <b>Prompt builder</b> (system prompt with scoring rubric + user prompt) &rarr; <b>LLM call</b> "
      "(temperature 0, JSON mode) &rarr; <b>JSON parsing &amp; validation in Python</b> &rarr; "
      "<b>Interactive result screen</b>. Main features of the interface:"),
    *bullets([
        "<b>Evaluate tab:</b> one-click sample buttons, live word counts and a keyword-overlap meter, a score "
        "gauge, a coloured grade badge and covered / partial / missing counts.",
        "<b>Editable rubric (teacher override):</b> the teacher can change any key point's status or marks, and "
        "the score, grade and charts update instantly. A reset button restores the AI marks.",
        "<b>Evidence highlighting</b> of matching phrases in the student answer, a <b>marks-per-point chart</b>, and a "
        "<b>compare grading styles</b> button (Lenient vs Balanced vs Strict).",
        "<b>Batch tab:</b> grades a whole CSV and shows class analytics (average, highest, lowest, pass rate, "
        "grade chart). <b>History tab:</b> score trend with re-open and CSV download.",
    ]),

    P("4. Procedure", h2),
    *numbered([
        "Understood the problem and listed the inputs and outputs needed.",
        "Created a free Groq / Gemini API key and stored it in a <i>.env</i> file (kept out of GitHub with <i>.gitignore</i>).",
        "Designed the scoring prompt and tested it in the provider's playground on 5 sample answers.",
        "Wrote <i>evaluator.py</i>: builds the prompt, calls the LLM, extracts the JSON and validates the marks.",
        "Built the interactive Streamlit UI in <i>app.py</i> with an editable rubric, Plotly charts, batch analytics and history.",
        "Tested on 5 different kinds of answers using <i>test_samples.py</i> and took screenshots of the outputs.",
        "Pushed the code to GitHub and wrote this report.",
    ]),

    P("5. Prompt Design", h2),
    P("The system prompt makes the LLM act as a fair examiner and follow a fixed scoring rubric, so that marks "
      "are explainable and consistent:"),
    *bullets([
        "Split the model answer (or the teacher's custom marking scheme) into 3-8 <b>key points</b> and give each a "
        "weight. The weights must add up exactly to the maximum marks.",
        "Mark each point as <b>covered</b> (full weight), <b>partial</b> (about half) or <b>missing</b> (0), and quote "
        "the evidence from the student answer.",
        "Deduct for factually <b>wrong statements</b> (capped at 20% of max marks). Judge meaning, not length or "
        "exact wording; ignore spelling mistakes.",
        "Award 0 for blank or off-topic answers and <b>ignore instructions written inside the student answer</b> "
        "(prompt-injection safety).",
        "Return only a JSON object: key_points, awarded_marks, missing_points, strengths, incorrect_statements, "
        "feedback and an improvement tip. A grading style (Lenient / Balanced / Strict) adjusts how strict the examiner is.",
    ]),
    P("<b>Validation in code:</b> the program does not blindly trust the LLM. It recalculates the total from the "
      "key-point marks, rescales if weights do not add up, clamps marks to 0...max, rounds to the nearest 0.5 "
      "and retries once if the reply does not follow the JSON schema. If a model has been retired by the "
      "provider, it automatically switches to an available one."),

    P("6. Testing on Sample Inputs", h2),
    P(f"Each sample was evaluated with <b>{escape(model_used)}</b>. The test cases cover different kinds of answers "
      "a teacher normally sees:"),
    table([["Question", "Test case", "Marks", "Main missing points"]] + results,
          [44 * mm, 36 * mm, 22 * mm, 72 * mm]),
]
if offline:
    story.append(P("<i>Note: these marks come from the offline keyword mode. Re-run "
                   "<b>python make_report.py --provider \"Groq (free)\"</b> to fill this table with LLM marks.</i>", small))

story += [
    P("7. Results and Observations", h2),
    *bullets([
        "The LLM gives credit for correct ideas written in the student's own words, which simple keyword matching "
        "cannot do. The water-cycle answer uses completely different words but still scores high.",
        "Partial answers get partial marks, and the rubric table clearly shows which points are missing.",
        "Wrong facts (e.g. \"normalization adds duplicate data\") are detected and listed separately.",
        "The off-topic answer that asks for full marks is given 0, so the prompt-injection protection works.",
        "Temperature 0 and a fixed rubric keep marks stable: over repeated runs the clearly good and clearly "
        "off-topic answers got the same marks, while borderline answers (Newton's laws, DBMS) varied by up to "
        "1 mark, so the teacher should review borderline cases.",
        "Comparing grading styles on the water-cycle answer gave 8 / 9 / 8 (Lenient / Balanced / Strict). A small "
        "spread like this means the answer is clearly good; a large spread flags a borderline answer.",
        "The editable rubric keeps the teacher in control. For example, marking the missed 'transpiration' point "
        "as partial raised the score from 9 to 9.5 instantly.",
        "Batch mode grades a full class in one go and shows class analytics and a CSV export.",
    ]),

    P("8. Limitations and Future Scope", h2),
    *bullets([
        "The score is a <b>suggestion</b>; the teacher should review it. Accuracy depends on the LLM and the model answer.",
        "Handwritten answer sheets are not supported yet. OCR or a vision model could be added to read scanned sheets.",
        "Diagrams, derivations and numerical steps are not evaluated.",
        "Future work: saving results to a database, comparing AI marks with human marks, and support for regional languages.",
    ]),

    P("9. Conclusion", h2),
    P("The Answer Sheet Evaluator shows that an LLM with a well-designed scoring rubric can grade descriptive "
      "answers quickly and explain its marks through key points, missing points and feedback. Running the output "
      "through validation code keeps the marks consistent and in range. This makes it a practical assistant "
      "that reduces the time teachers spend checking answers."),
]

doc = SimpleDocTemplate(args.out, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
                        topMargin=14 * mm, bottomMargin=13 * mm,
                        title="Answer Sheet Evaluator - Project Report", author=args.name.replace("&lt;", "").replace("&gt;", ""))


def footer(canvas, d):
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(colors.grey)
    canvas.drawRightString(A4[0] - 18 * mm, 8 * mm, f"Page {d.page}")
    canvas.drawString(18 * mm, 8 * mm, "PS 24 - Answer Sheet Evaluator")


doc.build(story, onFirstPage=footer, onLaterPages=footer)
print(f"Saved {args.out} (tests run with {model_used})")
