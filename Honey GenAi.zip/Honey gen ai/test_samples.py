"""
Run the evaluator on the 5 sample inputs and print a summary table.

    python test_samples.py                      # offline demo mode (no key needed)
    python test_samples.py "Groq (free)"        # real LLM (needs GROQ_API_KEY in .env)
"""
import sys

from dotenv import load_dotenv

from evaluator import evaluate_answer
from samples import SAMPLES

load_dotenv()
provider = sys.argv[1] if len(sys.argv) > 1 else "Offline demo (no LLM)"

print(f"Provider: {provider}\n")
print(f"{'Sample':40} {'Marks':>10} {'%':>7} {'Grade':>6}")
print("-" * 66)
for s in SAMPLES:
    r = evaluate_answer(s["question"], s["model_answer"], s["student_answer"], s["max_marks"],
                        provider=provider)
    print(f"{s['name'][:40]:40} {r.awarded_marks:>4g} / {r.max_marks:<3g} {r.percentage:>6}% {r.grade:>6}")
    for m in r.missing_points[:3]:
        print(f"{'':6}- missing: {m[:90]}")
    print()
