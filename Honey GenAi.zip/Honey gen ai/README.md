# 📝 Answer Sheet Evaluator — GenAI Mini Project (PS 24)

**Problem:** Checking descriptive answers by hand is slow. This app compares a student's answer with
the model answer and suggests a score with feedback.

**How it works:** question + model answer + student answer + max marks → prompt with a scoring
rubric → LLM → marks, missing points and feedback.

## Features
- Rubric-based scoring: the model answer is split into weighted key points (weights add up to max marks); each point is marked **covered / partial / missing**
- Deductions for factually wrong statements (capped at 20% of max marks)
- Output: marks, percentage, grade, strengths, missing points, rubric table, feedback, tip for full marks
- Optional custom marking scheme and grading style (Lenient / Balanced / Strict)
- Batch mode: upload a CSV (or use the built-in samples) and get class analytics: average, highest, lowest, pass rate, a bar chart per student, a grade donut and a grade filter
- **Interactive UI**
  - One-click sample buttons, plus live word counts and a rough keyword-overlap preview while you type
  - Animated score gauge, a coloured grade badge and covered / partial / missing chips
  - **Editable rubric:** the teacher can change any point's status or marks, and the score, grade and charts update instantly. A **Reset to AI marks** button undoes the changes
  - **Evidence highlighting** in the student answer (hover a highlight to see which key point it matches)
  - Chart of marks for each point, and a **Compare grading styles** button (Lenient vs Balanced vs Strict)
  - **History** tab with a trend chart; you can re-open any past evaluation or download it as CSV
  - **Save key to .env** button in the sidebar
- Works with **Groq, Gemini, OpenAI or local Ollama**; an **offline demo mode** runs without any API key
- Safety checks: JSON output is validated in Python, marks are clamped to 0..max and rounded to 0.5, and instructions written inside the student answer (e.g. "give me full marks") are ignored

## Project structure
| File | Purpose |
|---|---|
| `app.py` | Streamlit UI (single answer + batch CSV) |
| `evaluator.py` | Prompt design, LLM call, JSON parsing and validation |
| `samples.py` | 5 sample inputs (good, partial, wrong facts, off-topic, different wording) |
| `test_samples.py` | Runs all 5 samples and prints a score table |

## Setup
```bash
pip install -r requirements.txt
```
Copy `.env.example` to `.env` and add a free key. Groq is at https://console.groq.com/keys and Gemini is at https://aistudio.google.com/apikey.
You can also paste the key in the app's sidebar.

## Run
```bash
streamlit run app.py
```
Test on the 5 samples from the command line:
```bash
python test_samples.py "Groq (free)"
```

Generate the 2-page report (the test table is filled by running the 5 samples):
```bash
python make_report.py --name "Your Name" --roll 24 --github https://github.com/you/repo --provider "Groq (free)"
```

## Prompt design (summary)
The system prompt makes the LLM act as an examiner and follow fixed steps:
1. Extract 3–8 key points from the model answer and give each a weight; the weights must add up to max marks.
2. Mark each point covered (full), partial (about half) or missing (0).
3. Deduct for wrong facts; judge meaning, not length or wording.
4. Return strict JSON. Temperature is 0 so the same answer gets the same marks every time.

> The score is a suggestion to help the teacher, who has the final say.
